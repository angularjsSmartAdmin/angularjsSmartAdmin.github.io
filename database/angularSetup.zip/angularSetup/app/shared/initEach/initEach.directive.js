
// initEach directive declaration (gets initialized every time view changes)
directives.directive("initEach", function(){
	return {
		restrict: "A",
		link: function ($scope) {
			console.log("initEach");
		}
	};
});
