
// directives module declaration
var directives = angular.module("directives", []);
