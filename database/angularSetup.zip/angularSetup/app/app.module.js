
// Common ngModules and constants for project
var commonModule = angular.module("commonModule", ["ngRoute", "ngAnimate", "directives"]).constant({"cp": "app/components/"});

// Angular App Declaration
var mainApp = angular.module("mainApp", ["commonModule"]);
