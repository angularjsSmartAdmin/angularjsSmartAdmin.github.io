mainApp.registerController("dashboardController", ["$scope", "dashboardFactory", function($scope, dashboardFactory){
		console.log("dashboardController is loaded!");
		var self = this;
		var str = dashboardFactory.getStr();
		console.log(str);
		if(!localStorage["users"]) {
				console.log("Fetching api data!");
				dashboardFactory.getData().then(function(data){
						localStorage["users"] = JSON.stringify(data);
				});
		}
}]);
