mainApp.registerFactory("homeFactory", ["$http", "$q", function($http, $q){
    return {
        getStr: function () {
            return "Hello homeFactory!";
        },
        getData: function () {
            return $http.get("https://raw.githubusercontent.com/angularjsSmartAdmin/angularjsSmartAdmin.github.io/master/database/users.json")
            .then(
                function (response) {
                    return response.data;
                },
                function (errResponse) {
                    return $q.reject(errResponse);
                }
            );
        }
    };
}]);
