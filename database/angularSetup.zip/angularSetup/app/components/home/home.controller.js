mainApp.registerController("homeController", ["$scope", "homeFactory", function($scope, homeFactory){
	  console.log("homeController is loaded!");
		var self = this;
		var str = homeFactory.getStr();
		console.log(str);
		if(!localStorage["users"]) {
				console.log("Fetching api data!");
				homeFactory.getData().then(function(data){
						localStorage["users"] = JSON.stringify(data);
				});
		}
}]);
