
// Footer Controller
mainApp.controller("footerController", ["$scope", function($scope) {
		console.log("footerController is loaded!");
		var self = this;
}]);
