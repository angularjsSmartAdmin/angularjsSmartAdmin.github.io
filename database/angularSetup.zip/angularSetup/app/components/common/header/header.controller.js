
// Header Controller
mainApp.controller("headerController", ["$scope", function($scope) {
		console.log("headerController is loaded!");
		var self = this;
}]);
