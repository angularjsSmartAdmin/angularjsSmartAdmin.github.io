
// Angular App Routing and deffered loading of controllers according to views
mainApp.config(["$routeProvider", "$controllerProvider", "$provide", "cp", function($routeProvider, $controllerProvider, $provide, cp) {

	mainApp.registerController = $controllerProvider.register;

	mainApp.registerFactory = $provide.factory;

	function loadScript(path) {
		var result = $.Deferred();
		script = document.createElement("script");
		script.async = "async";
		script.type = "text/javascript";
		script.src = path;
		script.onload = script.onreadystatechange = function (_, isAbort) {
			if (!script.readyState || /loaded|complete/.test(script.readyState)) {
				if (isAbort) {
					result.reject();
				}
				else {
					result.resolve();
				}
			}
		};
		script.onerror = function () { result.reject(); };
		document.querySelector("#partialScripts").appendChild(script);
		return result.promise();
	}

	function lazyLoad(viewName, scriptData){
		return {
			load: function($q) {
					console.clear();
				  document.getElementById("partialScripts").innerHTML = "";
          var deferred = $q.defer(),
          map = scriptData.map(function(name) {
              return loadScript(cp + viewName + '/' + name + '.js');
          });
          $q.all(map).then(function(r){
              deferred.resolve();
          });
          return deferred.promise;
			}
		};
	}

	$routeProvider
		.when("/", {
			templateUrl: cp + "home/homeView.html",
			controller: "homeController as ctrl",
			resolve: lazyLoad('home', ['home.controller', 'home.factory'])
		})
		.when("/dashboard", {
			templateUrl: cp + "dashboard/dashboardView.html",
			controller: "dashboardController as ctrl",
			resolve: lazyLoad('dashboard', ['dashboard.controller', 'dashboard.factory'])
		})
		.otherwise({
			templateUrl: cp + "error/errorView.html",
			resolve: lazyLoad('error', [])
		});
}]);
