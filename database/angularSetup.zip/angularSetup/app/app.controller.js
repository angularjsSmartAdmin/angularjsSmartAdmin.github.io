
// Parent Controller
mainApp.controller("mainController", ["$scope", function($scope) {
		console.log("mainController is loaded!");
		var self = this;
		if(localStorage["users"]) {
				console.log("Clearing localStorage...");
				localStorage.removeItem("users");
		}
}]);
